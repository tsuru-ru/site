from flask import Flask, url_for, render_template, redirect, request
import db_session
from wtforms.fields.html5 import EmailField
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired
from flask_login import LoginManager, login_user, UserMixin
import sqlalchemy
import sqlalchemy.ext.declarative as dec

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)
SqlAlchemyBase = dec.declarative_base()


@app.route('/', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if request.method == 'GET':
        return render_template('login.html', title='Авторизация', form=form)
    elif request.method == 'POST':
        return login1()



@app.route('/login', methods=['GET', 'POST'])
def login1():
    if request.method == 'GET':
        return render_template('primer.html')
    elif request.method == 'POST':
        print(request.form['m'])
        print(request.form['a'])
        print(request.form['breakfest'], request.form['class1'])
        print(request.form['lunch'], request.form['class2'])
        print(request.form['night'], request.form['class3'])
        return "Форма отправлена"


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


class User(SqlAlchemyBase, UserMixin):
    __tablename__ = 'users'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    email = sqlalchemy.Column(sqlalchemy.String,
                              index=True, unique=True, nullable=True)
    hashed_password = sqlalchemy.Column(sqlalchemy.String, nullable=True)


if __name__ == '__main__':
    app.run(port=5000, host='127.0.0.1')
