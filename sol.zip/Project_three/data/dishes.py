import sqlalchemy
from .db_session import SqlAlchemyBase


class Dish(SqlAlchemyBase):
    __tablename__ = 'menu'

    name = sqlalchemy.Column(sqlalchemy.String,
                             primary_key=True, autoincrement=True)

    proteins = sqlalchemy.Column(sqlalchemy.Float, nullable=True)
    fats = sqlalchemy.Column(sqlalchemy.Float, nullable=True)
    carbohydrates = sqlalchemy.Column(sqlalchemy.Float, nullable=True)
    numberofcalories = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)

