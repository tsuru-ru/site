from flask import Flask, url_for, render_template, redirect, request
from flask_login import LoginManager, login_user, UserMixin
import sqlalchemy
from data import db_session
from data.dishes import Dish
from data.users import User

d = {'Liza': ['12345', "work.by.crane@yandex.ru"]}
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


@app.route('/', methods=['GET', 'POST'])
def login():
    db_session.global_init("db/ourMenu.db")
    db_sess = db_session.create_session()
    dishes = db_sess.query(Dish)
    if request.method == 'GET':
        return render_template('index.html')
    elif request.method == 'POST':
        e = request.form['email']
        n = request.form['name']
        p = request.form['password']
        if n in d:
            if d[n][0] == p and d[n][1]:
                return render_template('primer.html', dishes=dishes)
            else:
                return render_template('index.html')
        else:
            return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login1():
    db_session.global_init("db/ourMenu.db")
    db_sess = db_session.create_session()
    dishes = db_sess.query(Dish)
    if request.method == 'GET':
        return render_template('primer.html', dishes=dishes)
    elif request.method == 'POST':
        print(request.form['m'])
        print(request.form['a'])
        print(request.form['breakfast'], request.form['class1'])
        print(request.form['lunch'], request.form['class2'])
        print(request.form['night'], request.form['class3'])
        dr = []
        dr.append([request.form['class1'], int(request.form['breakfast'])])
        dr.append([request.form['class2'], int(request.form['lunch'])])
        dr.append([request.form['class3'], int(request.form['night'])])

        return calc(dr)


@login_manager.user_loader
def load_user(user_id):
    db_session.global_init("db/people.db")
    db_ses = db_session.create_session()
    return db_ses.query(User).get(user_id)


# @app.route('/menu', methods=['POST'])
def calc(dr):
    db_session.global_init("db/ourMenu.db")
    db_sess = db_session.create_session()
    dishes = db_sess.query(Dish)
    if request.method == 'POST':
        return render_template('calc.html', dishes=dishes, result=dr)

    # app.run()


if __name__ == '__main__':
    app.run(port=5000, host='127.0.0.1')
