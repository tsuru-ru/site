from flask import Flask, url_for, render_template, redirect, request
from wtforms.fields.html5 import EmailField
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired
from flask_login import LoginManager, login_user, UserMixin
import sqlalchemy



d = {'Liza': ['12345', "work.by.crane@yandex.ru"]}
app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('index.html')
    elif request.method == 'POST':
        e = request.form['email']
        n = request.form['name']
        p = request.form['password']
        if n in d:
            if d[n][0] == p and d[n][1]:
                return render_template('primer.html')
            else:
                return render_template('index.html')
        else:
            return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login1():
    if request.method == 'GET':
        return render_template('primer.html')
    elif request.method == 'POST':
        print(request.form['m'])
        print(request.form['a'])
        print(request.form['breakfest'], request.form['class1'])
        print(request.form['lunch'], request.form['class2'])
        print(request.form['night'], request.form['class3'])
        return "Форма отправлена"


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)





if __name__ == '__main__':
    app.run(port=5000, host='127.0.0.1')
